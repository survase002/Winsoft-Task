﻿using Microsoft.Data.SqlClient;


namespace _01DemoADO
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string connectionDetails = @"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=solapur;Integrated Security=True;";


            KDACDataContext dbContext =
                new KDACDataContext(connectionDetails);



            while (true)
            {
                Console.WriteLine("1: Select, 2: Insert, 3:Update, 4:Delete");
                int opchoice = Convert.ToInt32(Console.ReadLine());
                switch (opchoice)
                {
                    case 1:
                        dbContext.GetData();

                        foreach (Emp e in dbContext.Emps)
                        {
                            Console.WriteLine(e.ToString()); ;
                        }
                        break;

                    case 2:
                        Emp emp = new Emp();

                        Console.WriteLine("Enter No");
                        emp.No = Convert.ToInt32(Console.ReadLine());

                        Console.WriteLine("Enter Name");
                        emp.Name = Console.ReadLine();

                        Console.WriteLine("Enter Address");
                        emp.Address = Console.ReadLine();

                        dbContext.SendData(emp);

                        foreach (Emp e in dbContext.Emps)
                        {
                            Console.WriteLine(e.ToString()); ;
                        }

                        break;
                    case 3:
                        Emp emp1 = new Emp();

                        Console.WriteLine("ENter No to Update ");
                        int No = Convert.ToInt32(Console.ReadLine());

                        Console.WriteLine("Enter Name");
                        string name = Console.ReadLine();

                        Console.WriteLine("Enter Address");
                        string address = Console.ReadLine();

                        dbContext.UpdateData(emp1);

                        foreach (Emp e in dbContext.Emps)
                        {
                            Console.WriteLine(e.ToString()); ;
                        }

                        break;
                    case 4:

                        Console.WriteLine("ENter No to Delete ");
                        int No1 = Convert.ToInt32(Console.ReadLine());

                        dbContext.RemoveData(No1);

                        //dbContext.GetData();
                        foreach (Emp e in dbContext.Emps)
                        {
                            Console.WriteLine(e.ToString()); ;
                        }

                        break;

                    default:
                        break;
                }


                Console.WriteLine("Do you want to continue? yes / no");
                string choice = Console.ReadLine();
                if (choice == "no")
                {
                    break;
                }
            }



            Console.ReadLine();
        }
    }


    public class Emp
    {

        private int _No;
        private string _Name;
        private string _Address;

        public string Address
        {
            get { return _Address; }
            set { _Address = value; }
        }

        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }

        public int No
        {
            get { return _No; }
            set { _No = value; }
        }

        public override string ToString()
        {
            return string.Format("No = {0}, Name = {1}, Address= {2}", No, Name, Address);
        }
    }


    public abstract class BaseDataContext
    {


        protected abstract void GetDataFromDB();
        protected abstract void SendDataToDB(Emp emp);
        protected abstract void UpdateDataToDB(Emp emp);
        protected abstract void RemoveDataFromDB(int No);

        protected abstract string GetTableName();
        public void GetData()
        {

            GetDataFromDB();
        }
        public void SendData(Emp emp)
        {

            SendDataToDB(emp);

        }

        public void UpdateData(Emp emp)
        {

            UpdateDataToDB(emp);

        }

        public void RemoveData(int No)
        {

            RemoveDataFromDB(No);

        }


    }
    public class KDACDataContext : BaseDataContext
    {
        private string _ConnectionDetails;
        public string ConnectionDetails
        {
            get { return _ConnectionDetails; }
            set { _ConnectionDetails = value; }
        }

        private List<Emp> _Emps;
        public List<Emp> Emps
        {
            get { return _Emps; }
            set { _Emps = value; }
        }

        public KDACDataContext(string connectionDetails)
        {
            Emps = new List<Emp>();

            if (connectionDetails != null)
            {
                ConnectionDetails = connectionDetails;
            }
            else
            {
                throw new Exception("Connection Details Required!");
            }
        }

        protected override string GetTableName()
        {
            return "Emp";
        }
        protected override void GetDataFromDB()
        {
            SqlConnection connection =
                new SqlConnection(ConnectionDetails);
            connection.Open();

            SqlCommand command =
                new SqlCommand("select * from Emp", connection);

            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                Emp emp = new Emp();
                emp.No = Convert.ToInt32(reader["No"]);
                emp.Name = reader["Name"].ToString();
                emp.Address = reader["Address"].ToString();

                Emps.Add(emp);
            }

            connection.Close();
        }
        protected override void SendDataToDB(Emp emp)
        {
            SqlConnection connection =
                new SqlConnection(ConnectionDetails);

            connection.Open();

            string queryFormat = "insert into Emp(No,Name, Address) values({0}, '{1}','{2}')";

            string query = string.Format(queryFormat, emp.No, emp.Name, emp.Address);

            SqlCommand command =
                new SqlCommand(query, connection);

            int rowsAffected = command.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                Emps = new List<Emp>();
                GetData();
            }
            connection.Close();
        }
        protected override void UpdateDataToDB(Emp emp)
        {

            SqlConnection connection =
                new SqlConnection(ConnectionDetails);

            connection.Open();

            string queryFormat = "update Emp set Name = '{1}', Address= '{2}' where No = {0}";



            string query = string.Format(queryFormat, emp.No, emp.Name, emp.Address);

            SqlCommand command =
                new SqlCommand(query, connection);

            int rowsAffected = command.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                Emps = new List<Emp>();
                GetData();
            }

            connection.Close();

            Console.WriteLine("Rows affected = {0}", rowsAffected);

        }
        protected override void RemoveDataFromDB(int No)
        {
            SqlConnection connection =
                new SqlConnection(ConnectionDetails);

            connection.Open();

            string queryFormat = "delete from Emp where No = {0}";

            string query = string.Format(queryFormat, No);

            SqlCommand command =
                new SqlCommand(query, connection);

            int rowsAffected = command.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                Emps = new List<Emp>();
                GetData();
            }

            connection.Close();

            Console.WriteLine("Rows affected = {0}", rowsAffected);
        }
    }

}

